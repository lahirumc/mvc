-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2014 at 08:57 PM
-- Server version: 5.5.34
-- PHP Version: 5.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lp_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `article` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `author`, `article`, `date`) VALUES
(2, 'Article2', 'lahiru', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla consectetur porttitor dolor, ac egestas ante laoreet non. Proin non arcu quis lectus congue lacinia at sed urna. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vestibulum sodales leo sit amet justo tincidunt euismod sed nec justo. Integer imperdiet venenatis venenatis. Nam ultrices gravida venenatis. Pellentesque aliquet, tellus ac tempus adipiscing, tortor eros placerat purus, vel tincidunt magna enim nec orci. Phasellus sit amet accumsan urna. Nulla eleifend sit amet diam suscipit bibendum. Integer eleifend tellus nulla, ut fringilla risus facilisis et.', '2014-04-02');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `blog_id`, `email`, `name`, `comment`) VALUES
(1, 2, 'abc@mail.com', 'lahiru', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla consectetur porttitor dolor, ac egestas ante laoreet non. Proin non arcu quis lectus congue lacinia at sed urna'),
(9, 2, 'fdf@rer.com', 'fd', 'fghfgh'),
(12, 2, 'aaa@mail.com', 'aaa', 'aaaaaaa');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
