<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of blog_model
 *
 * @author Zeelabs
 */
class Blog_model extends CI_Model{

    //put your code here
    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->model('comment_model');
    }
    
    public function insertArticle($data){
        $this->db->insert('blog', $data);  
    }
    
    
    public function deleteArticle($id){
        
        $this->comment_model->deleteCommentByBlog($id);
        $this->db->delete('blog', array('id' => $id)); 
    }
    
    
    public function updateArticle($data,$id){
        
        $this->db->where('id', $id);
        $this->db->update('blog', $data);  
    }

    public function getAllBlogs() {

        $this->db->select('blog.*,COUNT(comments.blog_id) as `num`'); 
        $this->db->from('blog');
        $this->db->join('comments', 'blog.id = comments.blog_id','left');
        $this->db->group_by('blog.id'); 

        $query  = $this->db->get();
        return  $result = $query->result();
    }
    
    public function getBlogById($id){
        
        $this->db->select('blog.*,COUNT(comments.blog_id) as `num`'); 
        $this->db->from('blog');
        $this->db->join('comments', 'blog.id = comments.blog_id');
        $this->db->where('blog.id', $id);

        $query  = $this->db->get();
        $result = $query->row();
        
        $blog_row = new stdClass();
        
        $blog_row->id      = $result->id;
        $blog_row->title   = $result->title;
        $blog_row->author  = $result->author;
        $blog_row->article = $result->article;
        $blog_row->date    = $result->date;
        $blog_row->num     = $result->num;
        
        return $blog_row;
    }
    
    

}

?>
