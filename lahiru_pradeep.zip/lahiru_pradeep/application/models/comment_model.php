<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of comment_model
 *
 * @author Zeelabs
 */
class Comment_model extends CI_Model {

    //put your code here
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function insertComment($data){
        $this->db->insert('comments', $data);  
    }

    
     public function deleteComment($id){
        $this->db->delete('comments', array('id' => $id)); 
    }
    
    public function deleteCommentByBlog($id){
        $this->db->where('blog_id', $id);
        $this->db->delete('comments'); 
    }
    
    
    public function getCommentsByBlog($id) {
        
        $this->db->select('*');
        $this->db->from('comments');
        $this->db->where('blog_id', $id);

        $query = $this->db->get();
        return $result = $query->result();
    }
    
   
    


}

?>
