<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<div class="dashboard">
    <h1>Dashboard</h1>
    <a href="../blog/createarticle/">Add New Article</a>
    <br> <br>
    <table border="1">
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Article</th>
            <th>Comments</th>
            <th>Action</th>
        </tr>
        <?php foreach ($blogs as $row) {  ?>
        <tr>
            <td><?php echo $row->title ; ?></td>
            <td><?php echo $row->author ; ?></td>
            <td><?php echo substr($row->article, 0, 100) ?>...</td>
            <td><?php echo $row->num ; ?></td>
            <td><a href="../blog/updateatricle/<?php echo $row->id ?>">Edit</a> / <a href="../blog/removearticle/<?php echo $row->id ?>">Delete</a></td>
       </tr>
       <?php }?>
    </table>
</div>