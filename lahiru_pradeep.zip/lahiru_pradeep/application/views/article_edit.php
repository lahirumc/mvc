<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<div class="article-wrapper">
    
    <form method="post" action="../../blog/editarticle"  id="form_id" > 
        <input type="hidden" name="id" value="<?php echo $blog->id?>">
    <div>
        <label  for="title">Title* : </label>
        <input type="text" class="form-control validate[required,maxSize[100]]" size="30" id="title" name="title" value="<?php echo $blog->title?>" >
    </div>
    <div>
        <label class="lable" for="article">Article* : </label>
        <textarea class="form-control validate[required]" rows="10" cols="60" name="article" id="article"><?php echo $blog->article?></textarea>
    </div>

    <button type="submit" name="submit">Update</button>
    </form> 

    <h3><?php echo $blog->date?> by <?php echo $blog->author?></h3>
    <br>
    <hr>
    </br>
    <h4>number of comments <?php echo $blog->num?></h4>
    <div class="comment">
        <ul>
        <?php foreach($comments as $comment){?>
            <li> 
                <p><?php echo $comment->comment?><p>
                <h3> - <?php echo $comment->name?></h3>
                <a href="../../comment/removecomment/<?php echo $comment->id?>">Delete</a>
            </li> 
            <?php }?>
        </ul>
    </div>
</div>
