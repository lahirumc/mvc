<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<form name="form_add_article" method="post" action="../../blog/addarticle"  id="form_id" > 
    <div>
        <label  for="title">Title* : </label>
        <input type="text" class="form-control validate[required,maxSize[100]]" size="30" id="title" name="title" value="" >
    </div>
    <div>
        <label class="lable" for="article">Article* : </label>
        <textarea class="form-control validate[required]" cols="30" name="article" id="article"></textarea>
    </div>

    <button type="submit" name="submit">Save</button>
</form> 


