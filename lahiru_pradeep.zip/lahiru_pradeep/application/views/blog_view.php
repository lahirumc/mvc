<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="blog-area">
    <h1>Blog Articles</h1>
    <br> <br>
    <a href="admin/">Admin Area</a>
    <table border="1">
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Article</th>
            <th>Comments</th>
            <th>Action</th>
        </tr>
        <?php foreach ($blogs as $row) {  ?>
        <tr>
            <td><?php echo $row->title ; ?></td>
            <td><?php echo $row->author ; ?></td>
            <td><?php echo substr($row->article, 0, 100) ?>...</td>
            <td><?php echo $row->num ; ?></td>
            <td><a href="blog/viewatricle/<?php echo $row->id ?>">View</a></td>
       </tr>
       <?php }?>
    </table>
</div>