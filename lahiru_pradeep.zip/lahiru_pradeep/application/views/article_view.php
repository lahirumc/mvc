<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<div class="article-wrapper">
    <h1><?php echo $blog->title?></h1>
    <h3><?php echo $blog->date?> by <?php echo $blog->author?></h3>
    <p><?php echo $blog->article?></p>
    <h4>number of comments <?php echo $blog->num?></h4>
    <div class="comment">
        <ul>
        <?php foreach($comments as $comment){?>
            <li> 
                <p><?php echo $comment->comment?><p>
                <h3> - <?php echo $comment->name?></h3>
            </li> 
            <?php }?>
        </ul>
        <hr>

        <form name="form_add_comment" method="post" action="../../comment/addcomment"  id="form_id" > 
            <input type="hidden" name="id" value="<?php echo $blog->id?>">
            <div>
                <label  for="title">Name* : </label>
                <input type="text" class="form-control validate[required,maxSize[100]]" size="30" id="name" name="name" value="" >
            </div>
            <div>
                <label  for="title">Email* : </label>
                <input type="text" class="form-control validate[required,custom[email],maxSize[100]]" size="30" id="email" name="email" value="" >
            </div>
            <div>
                <label class="lable" for="description">comment* : </label>
                <textarea class="form-control validate[required,maxSize[255]]" cols="30" name="comment" id="comment"></textarea>
            </div>

            <button type="submit" name="submit"> Comment </button>
        </form> 
        
    </div>
</div>
