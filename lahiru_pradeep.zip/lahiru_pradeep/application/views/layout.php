<!DOCTYPE html>
<html>
    <head>
        <title>Article Management System</title>
        <link type="text/css"  href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
        <link type="text/css"  href="<?php echo base_url();?>assets/css/validationEngine.jquery.css" rel="stylesheet">
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-1.8.2.min.js" ></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.validationEngine.js" ></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.validationEngine-en.js" ></script>
        <script>jQuery(document).ready(function(){
            // binds form submission and fields to the validation engine
            jQuery("#form_id").validationEngine();
        });</script>
    </head>
    <body>
        <div class="container">
            <?php echo $content; ?>
        </div>
    </body>
</html>