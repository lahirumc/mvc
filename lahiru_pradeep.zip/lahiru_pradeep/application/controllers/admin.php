<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of admin
 *
 * @author Zeelabs
 */
class Admin  extends CI_Controller {
    //put your code here
    function __construct() {
        parent::__construct();
        $this->load->library(array('form_validation'));
        $this->load->helper(array('form', 'url', 'date'));
        $this->load->model('blog_model');
    }
    
    public function index() {
        $data['blogs']   = $this->blog_model->getAllBlogs();
        $data['content'] = $this->load->view('dashboard', $data, true);
        $this->load->view('layout', $data);
    }
}

?>
