<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of article
 *
 * @author Zeelabs
 */
class Blog extends CI_Controller {

    //put your code here
    function __construct() {

        parent::__construct();
        $this->load->library(array('form_validation'));
        $this->load->helper(array('form', 'url', 'date'));
        $this->load->model('blog_model');
        $this->load->model('comment_model');
    }

    public function index() {

        $data['blogs']   = $this->blog_model->getAllBlogs();
        $data['content'] = $this->load->view('blog_view', $data, true);
        $this->load->view('layout', $data);
    }
    
    public function createArticle() {

        $data['content'] = $this->load->view('article_add', null,true);
        $this->load->view('layout', $data);
    }
    
    public function viewAtricle($id){
        $data['blog']     = $this->blog_model->getBlogById($id);
        $data['comments'] = $this->comment_model->getCommentsByBlog($id);
        $data['content']  = $this->load->view('article_view', $data, true);
        $this->load->view('layout', $data);
    }
    
    public function updateAtricle($id){
        $data['blog']     = $this->blog_model->getBlogById($id);
        $data['comments'] = $this->comment_model->getCommentsByBlog($id);
        $data['content']  = $this->load->view('article_edit', $data, true);
        $this->load->view('layout', $data);
    }
    

    public function addArticle() {
        
        //server side form validation 
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('article', 'Article', 'required');

        //validation success
        if ($this->form_validation->run() == TRUE) {
            $article = array(
                'title'   => $this->input->post('title'),
                'article' => $this->input->post('article'),
                'author'  => 'Lahiru Pradeep', //user name from current login session
                'date'    => date("Y-m-d H:i:s")
            );

            $this->blog_model->insertArticle($article);
        } 
        redirect('/admin/', 'refresh');
    }
    
    
     public function editArticle() {
        
        //server side form validation 
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('article', 'Article', 'required');

        //validation success
        if ($this->form_validation->run() == TRUE) {
            $article = array(
                'title'   => $this->input->post('title'),
                'article' => $this->input->post('article'),
                'author'  => 'Lahiru Pradeep', //user name from current login session
                'date'    => date("Y-m-d H:i:s")
            );

            $this->blog_model->updateArticle($article,$this->input->post('id'));
        } 
        redirect('/admin/', 'refresh');
    }
    
    
    public function removeArticle($id){
        $this->blog_model->deleteArticle($id);
        redirect('/admin/', 'refresh');
    }

}

?>
