<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of comment
 *
 * @author Zeelabs
 */
class comment extends CI_Controller {
    //put your code here
    function __construct() {

        parent::__construct();
        $this->load->library(array('form_validation'));
        $this->load->helper(array('form', 'url', 'date'));
        $this->load->model('comment_model');
    }
    
    public function removeComment($id){
        $this->comment_model->deleteComment($id);
        redirect('/admin/', 'refresh');
    }
    
     public function addComment() {
        
        //server side form validation 
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('comment', 'Comment', 'required');

        //validation success
        if ($this->form_validation->run() == TRUE) {
            $comment = array(
                'name'    => $this->input->post('name'),
                'email'   => $this->input->post('email'),
                'comment' => $this->input->post('comment'),
                'blog_id' => $this->input->post('id')
            );

            $this->comment_model->insertComment($comment);
        } 
        redirect('/blog/viewatricle/'.$this->input->post('id'), 'refresh');
    }
}

?>
